﻿using NUnit.Framework;
using System;

namespace SampleGrid
{
    [TestFixture]
    public class RectangularSampleGrids
    {
        [Test]
        public void CanMakeSquareGrid()
        {
            int expectedWidth = 16;
            int expectedHeight = 16;
            int expectedCount = 256;

            var grid = new RectangularGrid<char>(expectedWidth, expectedHeight);

            Assert.AreEqual(expectedWidth, grid.Width, "Grid Width not set or reported correctly.");
            Assert.AreEqual(expectedHeight, grid.Height, "Grid Height not set or reported correctly.");
            Assert.AreEqual(expectedCount, grid.Count, "Grid Height not set or reported correctly.");
        }

        [Test]
        public void CanMakeRectangularGrid()
        {
            int expectedWidth = 16;
            int expectedHeight = 9;
            int expectedCount = 144;

            var grid = new RectangularGrid<char>(expectedWidth, expectedHeight);

            Assert.AreEqual(expectedWidth, grid.Width, "Grid Width not set or reported correctly.");
            Assert.AreEqual(expectedHeight, grid.Height, "Grid Height not set or reported correctly.");
            Assert.AreEqual(expectedCount, grid.Count, "Grid Height not set or reported correctly.");
        }

        [Test]
        public void CanMakeGridWithContents()
        {
            int expectedWidth = 2;
            int expectedHeight = 2;
            int expectedCount = 4;

            var grid = new RectangularGrid<char>(expectedWidth, expectedHeight, new char[] {
                // 0    1
                  'A', 'B', // 0
                  'C', 'D', // 1
            });

            Assert.AreEqual(expectedWidth, grid.Width, "Grid Width not set or reported correctly.");
            Assert.AreEqual(expectedHeight, grid.Height, "Grid Height not set or reported correctly.");
            Assert.AreEqual(expectedCount, grid.Count, "Grid Height not set or reported correctly.");

            Assert.AreEqual('A', grid.GetAtPoint(0, 0), "Grid Contents at (0, 0) incorrect.");
            Assert.AreEqual('B', grid.GetAtPoint(1, 0), "Grid Contents at (1, 0) incorrect.");
            Assert.AreEqual('C', grid.GetAtPoint(0, 1), "Grid Contents at (0, 1) incorrect.");
            Assert.AreEqual('D', grid.GetAtPoint(1, 1), "Grid Contents at (1, 1) incorrect.");
        }

        [Test]
        public void CannotMakeGridWithBadDimensions()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
            {
                var grid = new RectangularGrid<char>(2, 3, new char[] {
                    // 0    1
                      'A', 'B', // 0
                      'C', 'D', // 1
                });
            }, "Failed to throw ArgumentOutOfRangeException despite bad dimensions.");
        }

        [Test]
        public void GetFromSquareGrid()
        {
            var grid = new RectangularGrid<char>(3, 3, new char[] {
                // 0    1    2
                  'A', 'B', 'C', // 0
                  'D', 'E', 'F', // 1
                  'G', 'H', 'I', // 2
            });

            Assert.AreEqual('A', grid.GetAtPoint(0, 0), "Grid Contents at (0, 0) incorrect.");
            Assert.AreEqual('F', grid.GetAtPoint(2, 1), "Grid Contents at (1, 1) incorrect.");
            Assert.AreEqual('I', grid.GetAtPoint(2, 2), "Grid Contents at (2, 2) incorrect.");
        }

        [Test]
        public void SetInSquareGrid()
        {
            var grid = new RectangularGrid<char>(3, 3, new char[] {
                // 0    1    2
                  'A', 'B', 'C', // 0
                  'D', 'E', 'F', // 1
                  'G', 'H', 'I', // 2
            });

            grid.SetAtPoint('X', 0, 0);
            grid.SetAtPoint('Y', 2, 1);
            grid.SetAtPoint('Z', 2, 2);

            Assert.AreEqual('X', grid.GetAtPoint(0, 0), "Grid Contents at (0, 0) incorrect.");
            Assert.AreEqual('Y', grid.GetAtPoint(2, 1), "Grid Contents at (1, 1) incorrect.");
            Assert.AreEqual('Z', grid.GetAtPoint(2, 2), "Grid Contents at (2, 2) incorrect.");
        }

        [Test]
        public void GetFromRectangularGrid()
        {
            var grid = new RectangularGrid<char>(4, 2, new char[] {
                // 0    1    2    3
                  'A', 'B', 'C', 'D', // 0
                  'E', 'F', 'G', 'H', // 1
            });

            Assert.AreEqual('A', grid.GetAtPoint(0, 0), "Grid Contents at (0, 0) incorrect.");
            Assert.AreEqual('F', grid.GetAtPoint(1, 1), "Grid Contents at (1, 1) incorrect.");
            Assert.AreEqual('H', grid.GetAtPoint(3, 1), "Grid Contents at (3, 1) incorrect.");
        }

        [Test]
        public void SetInRectangularGrid()
        {
            var grid = new RectangularGrid<char>(4, 2, new char[] {
                // 0    1    2    3
                  'A', 'B', 'C', 'D', // 0
                  'E', 'F', 'G', 'H', // 1
            });

            grid.SetAtPoint('X', 0, 0);
            grid.SetAtPoint('Y', 1, 1);
            grid.SetAtPoint('Z', 3, 1);

            Assert.AreEqual('X', grid.GetAtPoint(0, 0), "Grid Contents at (0, 0) incorrect.");
            Assert.AreEqual('Y', grid.GetAtPoint(1, 1), "Grid Contents at (1, 1) incorrect.");
            Assert.AreEqual('Z', grid.GetAtPoint(3, 1), "Grid Contents at (3, 1) incorrect.");
        }
    }
}
