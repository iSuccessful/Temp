﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleGrid
{
    class RectangularGrid<T>
    {
        public readonly int Width;
        public readonly int Height;
        public readonly int Count;

        private readonly T[] contents;

        /// <summary>
        /// Creates a Rectangular Grid of the specified dimensions,
        /// filled with the default value for type T.
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public RectangularGrid(int width, int height) : this(width, height, new T[width * height]) { }

        /// <summary>
        /// Creates a Rectangular Grid of the specified dimensions,
        /// filled with supplied contents of type T.  Supplied contents
        /// must fit perfectly within specified grid dimensions (e.g.,
        /// a 2x2 grid must be given exactly 4 elements).
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="inContents"></param>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when given contents don't fit perfectly in specified grid dimensions.</exception>
        public RectangularGrid(int width, int height, IEnumerable<T> inContents)
        {
            Width = width;
            Height = height;
            Count = width * height;

            if (Count != inContents.Count())
            {
                throw new ArgumentOutOfRangeException($"Supplied grid contents must fit given dimensions: {Width} * {Height} == {Count} but also got {inContents.Count()} items to store.");
            }

            contents = inContents.ToArray();
        }

        /// <summary>
        /// Retrieves object in grid at (x, y) coordinate.
        /// </summary>
        /// <param name="x">Horizontal coordinate</param>
        /// <param name="y">Vertical coordinate</param>
        /// <returns>Object in grid at (x, y)</returns>
        public T GetAtPoint(int x, int y)
        {
            throw new NotImplementedException("TODO: Complete me!");
        }

        /// <summary>
        /// Stores object in grid at (x, y) coordinate.
        /// </summary>
        /// <param name="obj">Object to store in grid at (x, y)</param>
        /// <param name="x">Horizontal coordinate</param>
        /// <param name="y">Vertical coordinate</param>
        public void SetAtPoint(T obj, int x, int y)
        {
            throw new NotImplementedException("TODO: Complete me!");
        }
    }
}
