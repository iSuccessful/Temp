# Grid Test

An intro project that covers the basics of programming C# in Visual Studio, the usefulness of automated testing, and basic `git` + GitHub operations.

## Project Description

Many games use 2D rectangular grids for their game worlds, whether 2D games like [checkers]() and [Pokemon](https://i.imgur.com/K23DUDd.png) or 3D games like World of Warcraft (albiet as a way to [lay out 3D terrain tiles](https://i.imgur.com/tHiJrXK.png)).  These 2D grids have a width and height, with each cell containing important data (like a monster or terrain) that can be referenced using `(x, y)` coordinates.

For example, here is a small 3x3 grid of letters:

```
 ║0 1 2   x is horizontal
═╬═════   y is vertical
0║A B C
1║D E F   A is at (0, 0)
2║G H I   H is at (1, 2)
```

C# offers all kinds of collections, but they're mostly one-dimensional collections like arrays.  We COULD do mental gymnastics to consider this array the same grid, but it'll get annoying quickly:

```csharp
                        // 0    1    2    3    4    5    6    7    8
char[] arr = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I' };
// DON'T FORGET, if width == 3, every 4th item is a new row

char a = arr[0]; // a == 'A'
char h = arr[7]; // h == 'H'
arr[4] = 'X';    // center 'E' overwritten with 'X'
```

Using the original `(x, y)` coordinate syntax would be so much easier, especially while working on something already complicated like a 2D tile-based game.  Let's create a new collection `RectangularGrid` that wraps an array to do just that:

```csharp
var grid = new RectangularGrid<char>(3, 3, new char[] {
    // 0    1    2
      'B', 'B', 'C', // 0
      'D', 'E', 'F', // 1
      'G', 'H', 'I', // 2
});

char a = grid.GetAtPoint(0, 0); // a == 'A'
char h = grid.GetAtPoint(1, 2); // h == 'H'

grid.SetAtPoint('X', 1, 1);     // now (1, 1) => 'X', replacing 'E'

int width = grid.Width;         // width == 3
int height = grid.Height;       // height == 3
```

This means arbitrarily sized `RectangularGrid`s that track their own details and do their own math.  We only have to worry about where things are in-world, not how it's implemented.  A lot saner, huh?

## Automated Testing

Automated tests are used to quickly and accurately verify our code works as expected.  Think of it like a [Scantron Machine](https://www.youtube.com/watch?v=BzAxcXCiUFo) for programmers: we write simple tests that use our "real" code and automatically compare the results to hand-verified solutions.  If our tests cover enough basic behavior and corner cases correctly, the computer can warn us when new code or even future patches are broken.

Several pre-written tests have been included with this project to serve as a guide and self-grader.  In Visual Studio, click `Test > Windows > Test Explorer` to view the list of tests, then click `Run All` to see your progress.  Click on failed tests and read their error messages to see what went wrong.

![Opening Test Explorer](https://i.imgur.com/P17Q3Zv.png)
![Test Explorer](https://i.imgur.com/ZxEXj7B.png)

Do not change the tests themselves!  All work should be done in `RectangularGrid.cs`.  If a test itself seems badly written, contact @TomRichter to discuss the reasoning.

## Instructions

### Getting the Files

[Fork this repo] on GitHub, then `git clone` that fork to your local computer.  Create and switch to a new branch by running `git checkout -b YourNameHere` in a `Git Bash` terminal.  The result is a [separate space to work](https://guides.github.com/introduction/flow/) on your feature without fear of breaking the "main" branch, even when sharing in-progress changes with collaborators.

From the cloned folder, open `GridTest.sln` with Visual Studio.  In the `Solution Explorer` (usually on right, or `Ctrl Alt L`), open the `RectangularGrid.cs` file.

![Solution Explorer](https://i.imgur.com/6gR4Lsf.png)

### Completing the RectangularGrid

Implement the incomplete methods -- these are the ones with `throw new NotImplementedException("TODO: Complete me!")`.  Delete that line and write your own code.  Refer back to the Project Description and read the docstrings above each method for a description of its intended behavior.

Most of the work will be finding a way to convert `(x, y)` coordinates to an index into the underlying array `T[] contents`, where the objects are 

![Incomplete Method](https://i.imgur.com/fSnr46U.png)

Run the automated tests as you go (and as often as you like) to verify your progress.  For the easiest route, try passing tests in the following order:

  1. `CanMake*` tests, which cover creating new grids.
  2. `GetFrom*` tests, which cover retrieving existing grid contents.
  3. `SetIn*`  tests, which cover editing the grid contents.

### Submitting Your Work

Once all tests are passing, `git add .` and `git commit` your changes.  Be sure to write a short but helpful commit message (or mini-patch note) that describes the work you did.  Next, `git push -u origin YourNameHere` your new commit to GitHub and confirm it shows up on your project page.

Finally, create a "pull request" to submit your changes for review and have them merged back into the original repo.  On the GitHub project page, click `New Pull Request`, then `compare across forks` to set it up as follows:

![Pull Request](https://i.imgur.com/gayJOij.png)

Write a small blurb about what you did and click `Create Pull Request` to suggest these changes for the `master` branch.  Since you're your own repo maintainer, also `Merge pull request` and `delete branch` to accept the changes and delete the temporary branch you were working in until the feature was completed.

After all this, only `master` will remain with a completed `RectangularGrid`.  Good job!